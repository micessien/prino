<p>Hello dear <?php echo e($data['name']); ?></p>
<p>phone <?php echo e($data['phone']); ?></p>