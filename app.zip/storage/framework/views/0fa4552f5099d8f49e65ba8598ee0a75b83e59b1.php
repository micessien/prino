<?php $__env->startSection('content'); ?>
<!-- Start Banner 
============================================= -->
<div class="banner-area auto-height text-center text-normal text-light shadow dark-hard bg-fixed" style="background-image: url(assets/img/banner/11.jpg);">
    <div class="container">
        <div class="row justify-content-center padding-top-160">
            <div class="col-md-12">
                <div class="card card-register">
                    <div class="card-header text-shadow-10 text-white"><h1><?php echo e(__('Prix Hydrocarbures')); ?></h1></div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('users.store')); ?>" aria-label="<?php echo e(__('Register')); ?>" class="register">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="type" value="Hydrocarbures">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-11 col-md-offset-1">
                                            <div class="form-group">
                                                <select class="form-control<?php echo e($errors->has('genre') ? ' is-invalid' : ''); ?>" name="genre" id="genre" required style="height: 50px;">
                                                    <option value="M">M</option>
                                                    <option value="Mme">Mme</option>
                                                    <option value="Mlle">Mlle</option>
                                                </select>
                                                <?php if($errors->has('genre')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('genre')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-11 col-md-offset-1">
                                            <div class="form-group">
                                                <input id="entreprise" type="text" placeholder="Entreprise / Domaine d’activité" class="form-control<?php echo e($errors->has('entreprise') ? ' is-invalid' : ''); ?>" name="entreprise" value="<?php echo e(old('entreprise')); ?>" autofocus>

                                                <?php if($errors->has('entreprise')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('entreprise')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-1" style="line-height: 3;font-size: 20px;text-align: right;color: #ff0000;">*</div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input id="name" type="text" placeholder="Nom" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                                <?php if($errors->has('name')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-1" style="line-height: 3;font-size: 20px;text-align: right;color: #ff0000;">*</div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input id="email" type="email" placeholder="Adresse Email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                                <?php if($errors->has('email')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-1" style="line-height: 3;font-size: 20px;text-align: right;color: #ff0000;">*</div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input id="prenom" type="text" placeholder="Prénom(s)" class="form-control<?php echo e($errors->has('prenom') ? ' is-invalid' : ''); ?>" name="prenom" value="<?php echo e(old('prenom')); ?>" required autofocus>

                                                <?php if($errors->has('prenom')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('prenom')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-1" style="line-height: 3;font-size: 20px;text-align: right;color: #ff0000;">*</div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input id="password" type="password" placeholder="Mot de passe" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                                <?php if($errors->has('password')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-1" style="line-height: 3;font-size: 20px;text-align: right;color: #ff0000;">*</div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input id="telephone" type="text" placeholder="Téléphone" class="form-control<?php echo e($errors->has('telephone') ? ' is-invalid' : ''); ?>" name="telephone" value="<?php echo e(old('telephone')); ?>" required autofocus>

                                                <?php if($errors->has('telephone')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('telephone')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row">
                                        <div class="col-md-1" style="line-height: 3;font-size: 20px;text-align: right;color: #ff0000;">*</div>
                                        <div class="col-md-11">
                                            <div class="form-group">
                                                <input id="password-confirm" placeholder="Confirmer mot de passe" type="password" class="form-control<?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation" required>
                                                <?php if($errors->has('password_confirmation')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="checkbox">
                                            <label style="font-size: 16px; color: #ff0000; font-weight: 600;">
                                                <input type="checkbox" name="reglement" required /> Je déclare avoir lu et compris les conditions figurant au règlement du concours disponible
                                                    sous règlement et les accepter sans réserve. Je renonce à tout recours à l’encontre des
                                                    organisateurs et partenaires du concours, de leurs représentants ou des membres du jury. Je
                                                    certifie que tous les éléments fournis sont exacts et complets.
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="g-recaptcha" data-sitekey="<?php echo e(env('CAPTCHA_KEY')); ?>"></div>
                                        <?php if($errors->has('g-recaptcha-response')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('g-recaptcha-response')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary btn-vert btn-inscrire btn-lg"><?php echo e(__('Je termine')); ?></button>
                                </div>
                            </div>
                            <!-- Alert Message -->
                            <div class="col-md-12 alert-notification">
                                <div id="message" class="alert-msg"></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Banner -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>