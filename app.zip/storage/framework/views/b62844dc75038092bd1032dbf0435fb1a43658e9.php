<?php $__env->startSection('content'); ?>

<div class="panel panel-default">
        <div class="panel-heading" style="padding-bottom: 25px;">
                <h3 class="panel-title">Pièces Jointes</h3>
        </div>
        <div class="panel-body">

                <form action="/projects/create4" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-row">
                                <div class="form-group col-md-6">
                                        <label for="exampleFormControlFile1">Plan de financement projet (.docx)</label>
                                        <input name="planfin" value="<?php echo e($user->projects->planfin); ?>" type="file" class="form-control-file" id="exampleFormControlFile1">
                                </div>
                                <div class="form-group col-md-6">
                                        <label for="exampleFormControlFile2">Présentation Powerpoint du Projet</label>
                                        <input name="powerpoint" value="<?php echo e($user->projects->powerpoint); ?>" type="file" class="form-control-file" id="exampleFormControlFile2">
                                </div>
                                <div class="form-group col-md-6">
                                        <label for="exampleFormControlFile3">Business Plan</label>
                                        <input name="businessplan" value="<?php echo e($user->projects->businessplan); ?>" type="file" class="form-control-file" id="exampleFormControlFile3">
                                </div>
                                <div class="form-group col-md-6">
                                        <label for="exampleFormControlFile4">Declaration fiscale</label>
                                        <input name="declarationfiscale" value="<?php echo e($user->projects->declarationfiscale); ?>" type="file" class="form-control-file" id="exampleFormControlFile4">

                                </div>


                        </div>

                        <a href="<?php echo e(url('projects/index4')); ?>" class="btn btn-primary">Retour</a>
                        <button type="submit" class="btn btn-primary">J'ai terminé, je valide</button>
                </form>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>