<p>Hello dear {{ $data['name'] }}</p>
<p>phone {{ $data['phone'] }}</p>